param(
    [ValidateSet('Install', 'Restore', 'DryRun')]
    [string]$Mode = 'DryRun',
    [Parameter(Mandatory = $true)]
    [string]$GameRoot
)

$ErrorActionPreference = 'Stop'
$PackageId = 'AION2-PL-EXTRAS-20261014-v2'
$ExpectedNames = @(
    'pakchunk999995-Windows_999_P.utoc',
    'pakchunk999995-Windows_999_P.ucas',
    'pakchunk999995-Windows_999_P.pak',
    'pakchunk999997-Windows_999_P.pak'
)

function Get-Sha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Read-Json([string]$Path) {
    return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
}

function Assert-NoReparsePoint([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        $item = Get-Item -LiteralPath $Path -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse point is not allowed on a managed path: $Path"
        }
    }
}

$GameRoot = [IO.Path]::GetFullPath($GameRoot)
$AionRoot = Join-Path $GameRoot 'Aion2'
$ContentRoot = Join-Path $AionRoot 'Content'
$GameExe = Join-Path $GameRoot 'Aion2/Binaries/Win64/AION2.exe'
$PaksRoot = Join-Path $GameRoot 'Aion2/Content/Paks'
$ModsRoot = Join-Path $PaksRoot '~mods'
$StateRoot = Join-Path $GameRoot 'AION2-PL-EXTRAS'
$StatePath = Join-Path $StateRoot 'state.json'

if (-not (Test-Path -LiteralPath $GameExe -PathType Leaf) -or
    -not (Test-Path -LiteralPath $PaksRoot -PathType Container)) {
    throw 'GameRoot must contain Aion2/Binaries/Win64/AION2.exe and Aion2/Content/Paks.'
}
foreach ($managedPath in @($GameRoot, $AionRoot, $ContentRoot, $PaksRoot, $ModsRoot, $StateRoot)) {
    Assert-NoReparsePoint $managedPath
}
if (Get-Process -Name AION2 -ErrorAction SilentlyContinue) {
    throw 'Close AION2 before installing or restoring extras.'
}

if ($Mode -eq 'Restore') {
    if (-not (Test-Path -LiteralPath $StatePath -PathType Leaf)) { throw 'No extras ownership state was found.' }
    Assert-NoReparsePoint $StatePath
    $state = Read-Json $StatePath
    if ($state.packageId -cne $PackageId -or @($state.files).Count -ne $ExpectedNames.Count) {
        throw 'Ownership state is not recognized; nothing was removed.'
    }
    $stateNames = @($state.files | ForEach-Object { [string]$_.name })
    if (@($stateNames | Sort-Object -Unique).Count -ne $ExpectedNames.Count -or
        @($ExpectedNames | Where-Object { $_ -cnotin $stateNames }).Count -ne 0) {
        throw 'Ownership state contains unexpected file names; nothing was removed.'
    }
    foreach ($file in $state.files) {
        $target = Join-Path $ModsRoot $file.name
        Assert-NoReparsePoint $target
        if ((Test-Path -LiteralPath $target) -and -not (Test-Path -LiteralPath $target -PathType Leaf)) {
            throw "Owned target is not a regular file; nothing was removed: $($file.name)"
        }
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and (Get-Sha256 $target) -cne [string]$file.sha256) {
            throw "Owned file changed after install; nothing was removed: $($file.name)"
        }
    }
    foreach ($file in $state.files) {
        $target = Join-Path $ModsRoot $file.name
        if (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target }
    }
    Remove-Item -LiteralPath $StatePath
    if (@(Get-ChildItem -LiteralPath $StateRoot -Force).Count -eq 0) { Remove-Item -LiteralPath $StateRoot }
    Write-Output 'Extras removed. Only files with the recorded package hashes were deleted.'
    exit 0
}

$manifestPath = Join-Path $PSScriptRoot 'extras-manifest.json'
$payloadRoot = Join-Path $PSScriptRoot 'payload'
Assert-NoReparsePoint $PSScriptRoot
Assert-NoReparsePoint $manifestPath
Assert-NoReparsePoint $payloadRoot
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'extras-manifest.json is missing.' }
$manifest = Read-Json $manifestPath
if ($manifest.packageId -cne $PackageId -or $manifest.unsigned -ne $true -or $manifest.runtimeTested -ne $false) {
    throw 'Package manifest identity or test-status flags are invalid.'
}
if (@($manifest.files).Count -ne $ExpectedNames.Count) { throw 'Package must contain exactly four files.' }
$manifestNames = @($manifest.files | ForEach-Object { [string]$_.name })
if (@($manifestNames | Sort-Object -Unique).Count -ne $ExpectedNames.Count -or
    @($ExpectedNames | Where-Object { $_ -cnotin $manifestNames }).Count -ne 0) {
    throw 'Package has unexpected or duplicate filenames.'
}

foreach ($file in $manifest.files) {
    if ($file.name -cnotin $ExpectedNames -or [string]$file.name -match '[\\/:]' -or
        [string]$file.sha256 -notmatch '^[0-9a-f]{64}$') { throw 'Unsafe or invalid manifest entry.' }
    $source = Join-Path $payloadRoot $file.name
    Assert-NoReparsePoint $source
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Payload missing: $($file.name)" }
    if ((Get-Sha256 $source) -cne [string]$file.sha256) { throw "Payload hash mismatch: $($file.name)" }
}

if (Test-Path -LiteralPath $StateRoot) { throw 'An extras state directory already exists; refusing to overwrite it.' }
foreach ($existing in Get-ChildItem -LiteralPath $PaksRoot -Recurse -File -ErrorAction Stop) {
    if (@($ExpectedNames | Where-Object { $_ -ieq $existing.Name }).Count -gt 0) {
        throw "Filename already exists in Paks; refusing overwrite: $($existing.FullName)"
    }
}
if (Test-Path -LiteralPath $ModsRoot) {
    foreach ($name in $ExpectedNames) {
        if (Test-Path -LiteralPath (Join-Path $ModsRoot $name)) { throw "Target already exists: $name" }
    }
}

if ($Mode -eq 'DryRun') {
    Write-Output ("Dry run OK: {0} verified files would be placed only in Aion2/Content/Paks/~mods. No files were written." -f $ExpectedNames.Count)
    exit 0
}

$state = [ordered]@{
    packageId = $PackageId
    installedUtc = [DateTime]::UtcNow.ToString('o')
    files = @($manifest.files | ForEach-Object { [ordered]@{ name = [string]$_.name; sha256 = [string]$_.sha256 } })
}
$stateJson = $state | ConvertTo-Json -Depth 5
$modsCreated = $false
$stateCreated = $false
$createdNames = @()
try {
    if (-not (Test-Path -LiteralPath $ModsRoot)) {
        New-Item -ItemType Directory -Path $ModsRoot | Out-Null
        $modsCreated = $true
    }
    Assert-NoReparsePoint $ModsRoot
    New-Item -ItemType Directory -Path $StateRoot | Out-Null
    $stateCreated = $true
    Assert-NoReparsePoint $StateRoot
    Assert-NoReparsePoint $StatePath
    [IO.File]::WriteAllText($StatePath, $stateJson + "`n", (New-Object Text.UTF8Encoding($false)))
    foreach ($file in $manifest.files) {
        Assert-NoReparsePoint $ModsRoot
        $target = Join-Path $ModsRoot $file.name
        if (Test-Path -LiteralPath $target) { throw "Target appeared during install; refusing overwrite: $($file.name)" }
        $temp = Join-Path $ModsRoot ('.aion2-pl-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        try {
            Copy-Item -LiteralPath (Join-Path $payloadRoot $file.name) -Destination $temp
            if ((Get-Sha256 $temp) -cne [string]$file.sha256) { throw "Temporary copy hash mismatch: $($file.name)" }
            [IO.File]::Move($temp, $target)
            $createdNames += [string]$file.name
        } finally {
            if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp }
        }
        if ((Get-Sha256 $target) -cne [string]$file.sha256) { throw "Installed hash mismatch: $($file.name)" }
    }
} catch {
    $changed = @()
    foreach ($name in $createdNames) {
        $file = @($manifest.files | Where-Object { $_.name -ceq $name })[0]
        $target = Join-Path $ModsRoot $name
        if (Test-Path -LiteralPath $target -PathType Leaf) {
            if ((Get-Sha256 $target) -ceq [string]$file.sha256) { Remove-Item -LiteralPath $target }
            else { $changed += $name }
        }
    }
    if ($changed.Count -eq 0) {
        if ($stateCreated) {
            Remove-Item -LiteralPath $StatePath -ErrorAction SilentlyContinue
            if ((Test-Path -LiteralPath $StateRoot) -and @(Get-ChildItem -LiteralPath $StateRoot -Force).Count -eq 0) { Remove-Item -LiteralPath $StateRoot }
        }
        if ($modsCreated -and (Test-Path -LiteralPath $ModsRoot) -and @(Get-ChildItem -LiteralPath $ModsRoot -Force).Count -eq 0) {
            Remove-Item -LiteralPath $ModsRoot
        }
    } else {
        throw ("Install failed; changed files were preserved for manual review: {0}. Original error: {1}" -f ($changed -join ', '), $_.Exception.Message)
    }
    throw
}
Write-Output 'Extras installed. They are unsigned and game loading/runtime selection are untested.'
